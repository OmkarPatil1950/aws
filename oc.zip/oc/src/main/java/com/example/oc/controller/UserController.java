package com.example.oc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.oc.entity.User;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/books")
public class UserController 
{
	@Autowired
	com.example.oc.service.UserService service;
	
	
//	@GetMapping("/")
//	public String viewHome()
//	{
//		return "Registration";
//	}
//	
	@GetMapping("/")
	public String viewRegistration()
	{
		return "Registration";
	}
	
	@PostMapping("/save")
	public String save(@ModelAttribute("user") User user )
	{
		System.out.println("In spring boot");
		service.saveUser(user);
		return "UserList";
	}
	
//	@GetMapping("/list")
//    public String viewUserList(Model model) 
//	{
//        List<User> listuser = service.ListAll();
//        model.addAttribute("listuser", listuser);
//        //System.out.print("Get / ");
//        return "UserList";
//    }
}
