package com.example.oc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.oc.entity.User;
import com.example.oc.repo.UserRepository;


@Service
public class UserService 
{
	@Autowired
	UserRepository repo;
	
	public void saveUser(User user)
	{
		System.out.println("In service of spring booot");
		repo.save(user);
	}
	
	public List<User> ListAll()
	{
		return repo.findAll();
	}
}
